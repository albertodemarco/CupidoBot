﻿using System;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Configuration;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using System.Collections.Generic;
using Microsoft.ProjectOxford.Face;
using Microsoft.ProjectOxford.Face.Contract;
using Microsoft.ProjectOxford.Common.Contract;
using System.Text;
using Microsoft.Cognitive.CustomVision;
using Microsoft.ProjectOxford.Vision;
using System.Data.SqlClient;
using System.Collections;

namespace CupidoBotV1.Dialogs
{
    [Serializable]
    public class RootDialog : IDialog<object>
    {
        private FbResponse fbProfile=null;
        private CupidoProfile cpProfile = null;
        //private StateClient stateClient;
        public Task StartAsync(IDialogContext context)
        {
            //string AppID = ConfigurationManager.AppSettings["MicrosoftAppId"];
            //string AppPass = ConfigurationManager.AppSettings["MicrosoftAppPassword"];
            //stateClient = new StateClient(new MicrosoftAppCredentials(AppID, AppPass));
            context.Wait(MessageReceivedAsync);

            return Task.CompletedTask;
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<object> result)
        {
            IBotDataBag pr = context.PrivateConversationData;
            bool found=pr.TryGetValue<FbResponse>("fbResponse", out fbProfile);
            
            
            var wrp = await result as Activity;
         //   StateClient stateClient = wrp.GetStateClient();
          //  BotData userData = await stateClient.BotState.GetUserDataAsync(wrp.ChannelId, wrp.From.Id);
          //  var fbProfile = userData.GetProperty<FbResponse>("fbProfileG");
            //var data = context.UserData;
            //var fbProfile = data.GetValue<FbResponse>("fbProfileG");

            // calculate something for us to return
            if (found)
            {
                if (cpProfile == null || cpProfile.Gender ==null)
                {
                    cpProfile = mapDbProfile(fbProfile);
                    cpProfile.UserId = context.Activity.From.Id;
                    cpProfile.ChannelId = context.Activity.ChannelId;
                    if (wrp.Text.Equals("Sure!"))
                    {
                        string imageDesc = await findImageDescription(fbProfile.profile_pic);
                        await context.PostAsync($"Nice let's start! Looking now at your picture. I can see : " + imageDesc);
                        Face[] fc = await findFaceInfo(fbProfile.profile_pic);
                        string fcInfo = String.Empty;
                        foreach (Face f in fc)
                        {
                            fcInfo = fcInfo + FaceDescription(f);
                            cpProfile.Age = System.Convert.ToInt32(Math.Round(f.FaceAttributes.Age, 0));
                            cpProfile.Gender = f.FaceAttributes.Gender;
                            cpProfile.HairBald = (f.FaceAttributes.Hair.Bald > 0.5) ? 1 : 0;
                        }


                        await context.PostAsync("From your face I can see that: " + fcInfo);
                        ArrayList customVision = await customVisionPredictions(fbProfile.profile_pic);
                        cpProfile.SuperModelPoints = (customVision[1] as CupidoProfile).SuperModelPoints;
                        cpProfile.NormalPoints = (customVision[1] as CupidoProfile).NormalPoints;
                        await saveData(cpProfile);
                        //await context.PostAsync("Uhm I found that you are: "+ customVision[0] as string);
                        var messageModel = context.MakeMessage();
                        populateSuperModel(messageModel, cpProfile, customVision[0] as string);
                        await context.PostAsync(messageModel);
                    }


                }
                else if (wrp.Text.Equals("Find a match!"))
                {
                    await context.PostAsync("Let me find some candidates...");
                    //Find candidates
                    List<CupidoProfile> lst = getSimilarProfiles(cpProfile);
                    if (lst.Count > 0)
                    {
                        var messageSel = context.MakeMessage();
                        populateCarusel(messageSel, lst);
                        await context.PostAsync(messageSel);
                    }
                    else
                    {

                        await context.PostAsync("Sorry still no candidates for you, but come back and try again!");
                    }
                }
                else if (wrp.Text.Equals("No thanks"))
                {
                    await context.PostAsync($"Sorry");
                }
                else if (wrp.Text.StartsWith("I pick "))
                {
                    await context.PostAsync($"Good Choice!");
                }
                else
                {
                    await context.PostAsync($"Welcome Back! Resetting your data to start again");
                    pr.RemoveValue("fbResponse");
                    cpProfile = null;

                }
            }
            else
            {
                try
                {
                    FbResponse resp;
                    //string AppID = ConfigurationManager.AppSettings["MicrosoftAppId"];
                    //string AppPass = ConfigurationManager.AppSettings["MicrosoftAppPassword"];
                    //var connector = new ConnectorClient(new Uri(wrp.ServiceUrl),);
                    if (wrp.ChannelId == "facebook")
                    {
                        resp = await findInfoFromFb(wrp.From.Id);
                        
                    }
                    else
                    {
                        resp = new FbResponse();
                        resp.first_name = "Alberto";
                        resp.last_name = "Bot User";
                        resp.profile_pic = "https://media.licdn.com/mpr/mpr/shrink_200_200/AAEAAQAAAAAAAAjMAAAAJDU3OTY1YmFjLTk1YzEtNDE1OC05N2ViLTNiNmU2MjUzYjlkOA.jpg";

                    }
                    pr.SetValue<FbResponse>("fbResponse", resp);

                    //await context.PostAsync($"Hi {wrp.From.Name} welcome to Cupido Bot. Your profile says to me that your first name is {resp.first_name} and your gender is {resp.gender}");
                    var heroCard = new HeroCard
                    {
                        Title = "Cupido is here!",
                        Subtitle = "Find the perfect match!",
                        Text = $"Hello {resp.first_name}! Do you agree to continue?",
                        Images = new List<CardImage> { new CardImage(resp.profile_pic) },
                        Buttons = new List<CardAction> { new CardAction(ActionTypes.ImBack, title: "Sure!", value: "Sure!"), new CardAction(ActionTypes.ImBack, title: "No thanks", value: "No thanks") }
                    };
                    //Activity replyToConversation = wrp.CreateReply();
                    //replyToConversation.AttachmentLayout = AttachmentLayoutTypes.List;
                    //replyToConversation.Attachments = new List<Attachment>();
                    // Attachment plAttachment = heroCard.ToAttachment();
                    //replyToConversation.Attachments.Add(plAttachment);
                    //var userAccount = new ChannelAccount(wrp.From.Id, wrp.From.Name);
                    //var botAccount = new ChannelAccount(wrp.Recipient.Id, wrp.Recipient.Name);

                    //IMessageActivity message = Activity.CreateMessageActivity();
                    //message.ChannelId = wrp.ChannelId;
                    //string conversationId = (await connector.Conversations.CreateDirectConversationAsync(botAccount, userAccount)).Id;
                    //message.From = botAccount;
                    //message.Recipient = userAccount;
                    //message.Conversation = new ConversationAccount(id: conversationId);

                    //var connector = new ConnectorClient(new Uri(wrp.ServiceUrl));
                    //IMessageActivity message = wrp.CreateReply();
                    //message.AttachmentLayout = AttachmentLayoutTypes.List;
                    //message.Attachments = new List<Attachment>();
                    //Attachment plAttachment = heroCard.ToAttachment();
                    //message.Attachments.Add(plAttachment);
                    // await connector.Conversations.SendToConversationAsync((Activity)message);
                    var message = context.MakeMessage();
                    message.Attachments.Add(heroCard.ToAttachment());
                    await context.PostAsync(message);
                    //BotData userDataNew = new BotData("*",null);
                    //userDataNew.SetProperty<FbResponse>("fbProfileN", resp);
                    //await stateClient.BotState.SetUserDataAsync(wrp.ChannelId, wrp.From.Id, userDataNew);
                    //var data = context.UserData;
                    //data.SetValue<FbResponse>("fbProfileG", resp);
                    fbProfile = resp;
                    //var reply = await connector.Conversations.SendToConversationAsync(replyToConversation);


                    //await context.PostAsync(wrp);
                }
                catch (Exception excp)
                {
                    //Console.WriteLine(excp.Message);
                }
                // var reply = await connector.Conversations.SendToConversationAsync(wrp);
            }


            context.Wait(MessageReceivedAsync);
        }


        private async Task<FbResponse> findInfoFromFb(string userId)
        {
            FbResponse resp = new FbResponse();
            string accessToken = ConfigurationManager.AppSettings["FacebookPageAccessToken"];
            string url = "https://graph.facebook.com/v2.6/" + userId + "?fields=first_name,last_name,profile_pic&access_token=" + accessToken;
            //to change here to httpclient that should be better...
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";
            HttpWebResponse response = await request.GetResponseAsync() as HttpWebResponse;
            if (response.StatusCode == HttpStatusCode.OK)
            {
                Stream receiveStream = response.GetResponseStream();
                StreamReader sr = new StreamReader(receiveStream);
                resp = JsonConvert.DeserializeObject<FbResponse>(sr.ReadToEnd());
            }
            return resp;
        }
        private async Task<string> findImageDescription(string faceUrl)
        {
            string visionKey = ConfigurationManager.AppSettings["VisionKeyWestUs"];
            VisionServiceClient cli = new VisionServiceClient(visionKey, "https://westus.api.cognitive.microsoft.com/vision/v1.0");
            var AnalsysResult = await cli.DescribeAsync(faceUrl);
            return AnalsysResult.Description.Captions[0].Text;
        }
        private async Task<Face[]> findFaceInfo(string faceUrl)
        {
            string visionKey = ConfigurationManager.AppSettings["VisionKeyWestUs"];
            IFaceServiceClient faceServiceClient = new FaceServiceClient(visionKey, "https://westus.api.cognitive.microsoft.com/face/v1.0");

            Face[] faces;                   // The list of detected faces.
            String[] faceDescriptions;      // The list of descriptions for the detected faces.
            double resizeFactor;            // The resize factor for the displayed image.
            IEnumerable<FaceAttributeType> faceAttributes = new FaceAttributeType[] { FaceAttributeType.Gender, FaceAttributeType.Age, FaceAttributeType.Smile, FaceAttributeType.Emotion, FaceAttributeType.Glasses, FaceAttributeType.Hair,FaceAttributeType.Accessories,FaceAttributeType.Blur,FaceAttributeType.FacialHair,FaceAttributeType.HeadPose,FaceAttributeType.Makeup,FaceAttributeType.Noise,FaceAttributeType.Occlusion};
            faces = new Face[0];
            // Call the Face API.
            try
            {
               
                    faces = await faceServiceClient.DetectAsync(faceUrl, returnFaceId: true, returnFaceLandmarks: false, returnFaceAttributes: faceAttributes);
                    
                
            }
            // Catch and display Face API errors.
            catch (FaceAPIException f)
            {
                
            }
            // Catch and display all other errors.
            catch (Exception e)
            {
                
            }
            return faces;
        }
        private string FaceDescription(Face face)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("gender: ");

            // Add the gender, age, and smile.
            sb.Append(face.FaceAttributes.Gender);
            sb.Append(", age: ");
            sb.Append(face.FaceAttributes.Age);
            sb.Append(", ");
            sb.Append(String.Format("smile {0:F1}%, ", face.FaceAttributes.Smile * 100));

            // Add the emotions. Display all emotions over 10%.
            sb.Append("Emotion: ");
            EmotionScores emotionScores = face.FaceAttributes.Emotion;
            if (emotionScores.Anger >= 0.1f) sb.Append(String.Format("anger {0:F1}%, ", emotionScores.Anger * 100));
            if (emotionScores.Contempt >= 0.1f) sb.Append(String.Format("contempt {0:F1}%, ", emotionScores.Contempt * 100));
            if (emotionScores.Disgust >= 0.1f) sb.Append(String.Format("disgust {0:F1}%, ", emotionScores.Disgust * 100));
            if (emotionScores.Fear >= 0.1f) sb.Append(String.Format("fear {0:F1}%, ", emotionScores.Fear * 100));
            if (emotionScores.Happiness >= 0.1f) sb.Append(String.Format("happiness {0:F1}%, ", emotionScores.Happiness * 100));
            if (emotionScores.Neutral >= 0.1f) sb.Append(String.Format("neutral {0:F1}%, ", emotionScores.Neutral * 100));
            if (emotionScores.Sadness >= 0.1f) sb.Append(String.Format("sadness {0:F1}%, ", emotionScores.Sadness * 100));
            if (emotionScores.Surprise >= 0.1f) sb.Append(String.Format("surprise {0:F1}%, ", emotionScores.Surprise * 100));

            // Add glasses.
            sb.Append(face.FaceAttributes.Glasses);
            sb.Append(", ");

            // Add Accessories.
            sb.Append("Accessories:");
            sb.Append(", ");
            Accessory[] acc = face.FaceAttributes.Accessories;
            foreach (Accessory c in acc)
            {
                if (c.Confidence >= 0.1f)
                {
                    sb.Append(c.Type.ToString());
                    sb.Append(String.Format(" {0:F1}% ", c.Confidence * 100));
                }
            }
            // Add Occlusion.
            //sb.Append("Occlusion:");
            //sb.Append(", ");
            //Occlusion oc = face.FaceAttributes.Occlusion;
            //sb.Append("EyeOccluded "+oc.EyeOccluded);
            //sb.Append(", ");
            //sb.Append("ForeheadOccluded " + oc.ForeheadOccluded);
            //sb.Append(", ");
            //sb.Append("MouthOccluded " + oc.MouthOccluded);
            //sb.Append(", ");

            //Makeup m =face.FaceAttributes.Makeup;
            // Add Makeup.
            //sb.Append("Makeup:");
            //sb.Append(", ");
            //sb.Append("EyeMakeup " + m.EyeMakeup);
            //sb.Append(", ");
            //sb.Append("LipMakeup " + m.LipMakeup);
            //sb.Append(", ");

            // Add hair.
            sb.Append("Hair: ");

            // Display baldness confidence if over 10%.
            if (face.FaceAttributes.Hair.Bald >= 0.1f)
                sb.Append(String.Format("bald {0:F1}% ", face.FaceAttributes.Hair.Bald * 100));

            // Display all hair color attributes over 10%.
            HairColor[] hairColors = face.FaceAttributes.Hair.HairColor;
            foreach (HairColor hairColor in hairColors)
            {
                if (hairColor.Confidence >= 0.1f)
                {
                    sb.Append(hairColor.Color.ToString());
                    sb.Append(String.Format(" {0:F1}% ", hairColor.Confidence * 100));
                }
                break;
            }

            // Return the built string.
            return sb.ToString();
        }

        private async Task<ArrayList> customVisionPredictions(string imageUrl)
        {
            ArrayList lst = new ArrayList();
            CupidoProfile cp = new CupidoProfile();
            string retVal = String.Empty;
            string predictionKey = ConfigurationManager.AppSettings["CustomVisionKey"];
            string iterationId= ConfigurationManager.AppSettings["CustomVisionIterationId"];
            string projectId = ConfigurationManager.AppSettings["ProjectIdKey"];
            Guid projeczIdGuid = new Guid(projectId);
            Guid iterationGuid = new Guid(iterationId);
            Microsoft.Cognitive.CustomVision.Models.ImageUrl url = new Microsoft.Cognitive.CustomVision.Models.ImageUrl(imageUrl);
            PredictionEndpointCredentials predictionEndpointCredentials = new PredictionEndpointCredentials(predictionKey);
            PredictionEndpoint endpoint = new PredictionEndpoint(predictionEndpointCredentials);
            endpoint.BaseUri = new Uri ("https://customvisionppe.azure-api.net/v1.0/Prediction/");  
            try
            {           
                Microsoft.Cognitive.CustomVision.Models.ImagePredictionResultModel result = await endpoint.PredictImageUrlAsync(projeczIdGuid, url,iterationGuid);
                int counter = 0;
                foreach (var c in result.Predictions)
                {
                    retVal=retVal+$"{c.Tag}: {c.Probability:P1}";
                    if (c.Tag.Contains("Model1"))
                    { 
                        cp.SuperModelPoints = System.Convert.ToInt32(Math.Round(c.Probability*100, 0));
                    }
                    else
                    {
                        cp.NormalPoints = System.Convert.ToInt32(Math.Round(c.Probability*100, 0));
                    }
                    counter++;
                }
            }
            catch(Exception excp)
            {

            }
            retVal = retVal.Replace("Model2", " Normal ");
            retVal = retVal.Replace("Model1", " Super Model ");
            lst.Add(retVal);
            lst.Add(cp);
            return lst;

        }

        private async Task saveData(CupidoProfile i)
        {

            DateTime dt = DateTime.Now;

            string myConnStr = ConfigurationManager.ConnectionStrings["CupidoConn"].ConnectionString;
            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                builder.ConnectionString = myConnStr;

                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {
                    
                    connection.Open();

                    StringBuilder sb = new StringBuilder();
                    sb.Append("SELECT TOP 1 Id ");
                    sb.Append("FROM Cupido ");
                    sb.Append("WHERE ");
                    sb.Append("UserId='"+i.UserId+ "' AND ChannelId='"+i.ChannelId+"';");
                    String sql = sb.ToString();
                    long Id = -1;

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                Id= reader.GetInt64(0);
                            }
                        }
                    }

                    if (Id != -1)
                    {
                        string query = "UPDATE Cupido SET Gender=@Gender,Age=@Age,PicUrl=@PicUrl,NormalPoints=@NormalPoints,SuperModelPoints=@SuperModelPoints,HairBald=@HairBald,FirstName=@FirstName,LastName=@LastName,Updated=@Updated WHERE Id="+Id.ToString();
                        
                        SqlCommand myCommand = new SqlCommand(query, connection);
                        myCommand.Parameters.AddWithValue("@Gender", i.Gender);
                        myCommand.Parameters.AddWithValue("@Age", i.Age);
                        myCommand.Parameters.AddWithValue("@PicUrl", i.picUrl);
                        myCommand.Parameters.AddWithValue("@NormalPoints", i.NormalPoints);
                        myCommand.Parameters.AddWithValue("@SuperModelPoints", i.SuperModelPoints);
                        myCommand.Parameters.AddWithValue("@HairBald", i.HairBald);
                        myCommand.Parameters.AddWithValue("@FirstName", i.FirstName);
                        myCommand.Parameters.AddWithValue("@LastName", i.LastName);
                         myCommand.Parameters.AddWithValue("@Updated", dt);
                        // ... other parameters
                        await myCommand.ExecuteNonQueryAsync();
                    }
                    else
                    {
                        string query = "INSERT INTO Cupido (UserId,ChannelId,Gender,Age,PicUrl,NormalPoints,SuperModelPoints,HairBald,FirstName,LastName,Created,Updated)";
                        query += " VALUES (@UserId, @ChannelId, @Gender, @Age,@PicUrl, @NormalPoints, @SuperModelPoints, @HairBald, @FirstName, @LastName, @Created,@Updated)";

                        SqlCommand myCommand = new SqlCommand(query, connection);
                        myCommand.Parameters.AddWithValue("@UserId", i.UserId);
                        myCommand.Parameters.AddWithValue("@ChannelId", i.ChannelId);
                        myCommand.Parameters.AddWithValue("@Gender", i.Gender);
                        myCommand.Parameters.AddWithValue("@Age", i.Age);
                        myCommand.Parameters.AddWithValue("@PicUrl", i.picUrl);
                        myCommand.Parameters.AddWithValue("@NormalPoints", i.NormalPoints);
                        myCommand.Parameters.AddWithValue("@SuperModelPoints", i.SuperModelPoints);
                        myCommand.Parameters.AddWithValue("@HairBald", i.HairBald);
                        myCommand.Parameters.AddWithValue("@FirstName", i.FirstName);
                        myCommand.Parameters.AddWithValue("@LastName", i.LastName);
                        myCommand.Parameters.AddWithValue("@Created", dt);
                        myCommand.Parameters.AddWithValue("@Updated", dt);
                        // ... other parameters
                        await myCommand.ExecuteNonQueryAsync();


                    }

                }
            }
            catch (SqlException e)
            {
               
            }

        }

        private List<CupidoProfile> getSimilarProfiles(CupidoProfile i)
        {

            List<CupidoProfile> result = new List<CupidoProfile>();
            int agemin = i.Age - 15;
            int agemax = i.Age + 15;
            string myConnStr = ConfigurationManager.ConnectionStrings["CupidoConn"].ConnectionString;
            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                builder.ConnectionString = myConnStr;

                using (SqlConnection connection = new SqlConnection(builder.ConnectionString))
                {

                    connection.Open();

                    StringBuilder sb = new StringBuilder();
                    sb.Append("SELECT TOP 3 ChannelId,Gender,Age,PicUrl,NormalPoints,SuperModelPoints,HairBald,FirstName,LastName,UserId ");
                    sb.Append("FROM Cupido ");
                    sb.Append("WHERE ");
                    sb.Append("Age >= " + agemin + " AND Age <= " + agemax + " ");
                    sb.Append("AND Gender<>'" + i.Gender + "' ");
                    sb.Append("Order By SuperModelPoints DESC;");
                    String sql = sb.ToString();


                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                CupidoProfile cp = new CupidoProfile();
                                cp.ChannelId = reader.GetString(0);
                                cp.Gender = reader.GetString(1);
                                cp.Age = reader.GetInt32(2);
                                cp.picUrl = reader.GetString(3);
                                cp.NormalPoints = reader.GetInt32(4);
                                cp.SuperModelPoints = reader.GetInt32(5);
                                cp.HairBald = reader.GetBoolean(6)?1:0;
                                cp.FirstName = reader.GetString(7);
                                cp.LastName = reader.GetString(8);
                                cp.UserId = reader.GetString(9);
                                result.Add(cp);
                            }
                        }
                    }
                }
            }
            catch (SqlException e)
            {

            }


            return result;  
        }
        private void populateSuperModel(IMessageActivity replyToConversation, CupidoProfile cp, string description)
        {
            replyToConversation.AttachmentLayout = AttachmentLayoutTypes.List;
            replyToConversation.Attachments = new List<Attachment>();
            string maleUrl = "http://3.bp.blogspot.com/_m03cGx-c3FM/TNCGmbFBJyI/AAAAAAAAAI0/cHHgduezFKY/s1600/seanopry6.jpg";
            string femaleUrl = "https://qph.ec.quoracdn.net/main-qimg-12faf75897651d6cc546fb4c0ccb862c-c";
            string maleKoUrl = "http://wwwimage1.cbsstatic.com/thumbnails/photos/w370/gallery/matt2.jpg";
            string femaleKoUrl = "https://i.pinimg.com/originals/b4/43/54/b4435420b49ea667241a0f4f1644c9e7.jpg";

            string okStr = "You look like a Super Model!";
            string koStr = "Sorry you don't look like a Super Model!";
            string finalStr = okStr;

            string finalUrl = maleUrl;
            if (cp.Gender == "female")
            {
                finalUrl = femaleUrl;
            }
            if (cp.NormalPoints > 50)
            {
                finalStr = koStr;
                finalUrl = maleKoUrl;
                if (cp.Gender == "female")
                {
                    finalUrl = femaleKoUrl;
                }
            }
            HeroCard plCard = new HeroCard()
            {
                Title = $"{finalStr}",
                Subtitle = $"{description} ",
                Images = new List<CardImage> { new CardImage(finalUrl) },
                Buttons = new List<CardAction> { new CardAction(ActionTypes.ImBack, title: "Find a match!", value: "Find a match!") }
            };

            Attachment plAttachment = plCard.ToAttachment();
            replyToConversation.Attachments.Add(plAttachment);
        }

        private void populateCarusel(IMessageActivity replyToConversation, List<CupidoProfile> lst)
        {
            
            replyToConversation.AttachmentLayout = AttachmentLayoutTypes.Carousel;
            replyToConversation.Attachments = new List<Attachment>();

  

            foreach (CupidoProfile cp in lst)
            {
                HeroCard plCard = new HeroCard()
                {
                    Title = $"{cp.FirstName} {cp.LastName}",
                    Subtitle = $"{cp.Age} years old",
                    Images = new List<CardImage> { new CardImage(cp.picUrl) },
                    Buttons = new List<CardAction> { new CardAction(ActionTypes.ImBack, title: "Ok!", value: $"I pick {cp.UserId} on channel {cp.ChannelId}") }
                };

                Attachment plAttachment = plCard.ToAttachment();
                replyToConversation.Attachments.Add(plAttachment);
            }

          

        }



        private CupidoProfile mapDbProfile(FbResponse fb)
        {
            CupidoProfile cp = new CupidoProfile();
            cp.FirstName = fb.first_name;
            cp.LastName = fb.last_name;
            cp.Gender = fb.gender;
            cp.picUrl = fb.profile_pic;

            return cp;
        }


    }

    [Serializable]
    public class CupidoProfile
    {
        public string UserId { get; set; }
        public string ChannelId { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public int NormalPoints { get; set; }
        public int SuperModelPoints { get; set; }
        public int HairBald { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string picUrl { get; set; }
    }

    [Serializable]
    public class LastAdReferral
    {
        public string source { get; set; }
        public string type { get; set; }
        public string ad_id { get; set; }
    }
    [Serializable]
    public class FbResponse
    {
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string profile_pic { get; set; }
        public string locale { get; set; }
        public int timezone { get; set; }
        public string gender { get; set; }
        public LastAdReferral last_ad_referral { get; set; }
    }
}